package com.example.bpscnotes.data.remote.api

import com.example.bpscnotes.data.remote.dto.ApiResponse
import com.google.gson.annotations.SerializedName
import retrofit2.http.*

// ════════════════════════════════════════════════════════════
// FILE: data/remote/api/TierRoomsApiService.kt
//
// All DTOs + Retrofit interfaces for the Tier-Based Study Room
// system. Mirrors the backend TierRoomsModule APIs exactly.
// ════════════════════════════════════════════════════════════

// ── Tier DTOs ─────────────────────────────────────────────────

data class RoomTierDto(
    val id: String,
    @SerializedName(value = "tier_key", alternate = ["tierKey"])
    val tierKey: String,
    // @SerializedName("tierKey")       val tier_Key: String?="null",

    val name: String?,
    val description: String?,
    @SerializedName(value = "color_hex", alternate = ["colorHex"])
    val colorHex: String = "#9E9E9E",
    @SerializedName("icon_emoji")     val iconEmoji: String,      // "🥈"
    @SerializedName(value = "sort_order", alternate = ["sortOrder"])
    val sortOrder: Int = 0,
    @SerializedName("max_members")    val maxMembers: Int,
    @SerializedName(value = "coin_multiplier", alternate = ["coinMultiplier"])
    val coinMultiplier: Double = 1.0,
    @SerializedName(value = "xp_multiplier", alternate = ["xpMultiplier"])
    val xpMultiplier: Double = 1.0,
    val perks: List<String> = emptyList(),
    @SerializedName("total_members")  val totalMembers: Int = 0,
    @SerializedName("active_sessions") val activeSessions: Int = 0,
    // getMyTier currentTier uses camelCase — Gson picks first non-null
    @SerializedName("memberCount")    val memberCount: Int = 0,
    @SerializedName("activeNow")      val activeNow: Int = 0,
    @SerializedName("is_active")      val isActive: Boolean = true
) {
    // Unified getters — getAllTiers returns snake_case from DB aggregate,
    // getMyTier/currentTier returns camelCase from service code.
    // These cover both so screens don't need to worry which endpoint populated the DTO.
    val displayMembers: Int get() = if (memberCount > 0) memberCount else totalMembers
    val displayActive:  Int get() = if (activeNow > 0) activeNow else activeSessions
}

data class TierProgressItemDto(
    val label: String,      // "Study Hours" | "Streak" | "Quizzes" | "Accuracy"
    val current: Double,
    val required: Double,
    val unit: String,       // "h" | "days" | "quizzes" | "%"
    val done: Boolean       // true = this condition is met
)

data class NextTierDto(
    val id: String,
    @SerializedName("tier_key")   val tierKey: String,
    val name: String,
    @SerializedName(value = "icon_emoji", alternate = ["iconEmoji"])
    val iconEmoji: String = "🥈",
)

data class UserTierStatsDto(
    @SerializedName("total_study_hours")   val totalStudyHours: Double,
    val streak: Int,
    @SerializedName("quizzes_attempted")   val quizzesAttempted: Int,
    val accuracy: Double,
    val xp: Int,
    @SerializedName("xp_level")            val xpLevel: Int,
    val coins: Int
)

/**
 * Response for GET /rooms/tiers/my
 * Contains: current tier, next tier, per-condition progress, user stats
 */
data class MyTierResponseData(
    @SerializedName("currentTier")      val currentTier: RoomTierDto,
    @SerializedName("nextTier")         val nextTier: NextTierDto?,
    @SerializedName("promotedAt")       val promotedAt: String?,
    @SerializedName("nextTierProgress") val nextTierProgress: Double, // 0.0-1.0
    @SerializedName("progressItems")    val progressItems: List<TierProgressItemDto>,
    @SerializedName("demotionGraceUntil") val demotionGraceUntil: String?,
    @SerializedName("userStats")        val userStats: UserTierStatsDto
)

data class TiersListResponseData(
    val tiers: List<RoomTierDto> = emptyList()
)

// ── Leaderboard DTOs ──────────────────────────────────────────

data class LeaderboardEntryDto(
    @SerializedName("rank_position")   val rankPositionRaw: Any? = null,  // backend may send Int or String
    @SerializedName("study_minutes")   val studyMinutes: Int = 0,
    @SerializedName("study_minutes_today") val studyMinutesToday: Int = 0,
    @SerializedName("coins_earned")    val coinsEarned: Int = 0,
    @SerializedName("xp_earned")       val xpEarned: Int = 0,
    @SerializedName("goals_completed") val goalsCompleted: Int = 0,
    @SerializedName("streak_days")     val streakDays: Int = 0,
    @SerializedName("user_id")         val userId: String = "",
    @SerializedName("user_name")       val userName: String = "",
    @SerializedName("xp_level")        val xpLevel: Int = 1,
    @SerializedName("avatar_url")      val avatarUrl: String? = null
) {
    val rankPosition: Int get() = when (rankPositionRaw) {
        is Int    -> rankPositionRaw
        is Long   -> rankPositionRaw.toInt()
        is Double -> rankPositionRaw.toInt()
        is String -> rankPositionRaw.toIntOrNull() ?: 0
        else      -> 0
    }
}

data class LeaderboardResponseData(
    val leaderboard: List<LeaderboardEntryDto> = emptyList(),
    val period: String,         // "weekly"|"monthly"|"alltime"
    @SerializedName("periodKey") val periodKey: String  // "2026-W19"
)

// ── Tier Members ──────────────────────────────────────────────

data class TierMemberDto(
    val id: String,
    val name: String,
    val streak: Int,
    @SerializedName("longest_streak")    val longestStreak: Int = 0,
    @SerializedName("avatar_url")        val avatarUrl: String? = null,
//    @SerializedName("quizzes_attempted") val quizzesAttempted: Int,
//    val accuracy: Double,
//    val coins: Int,
//    val xp: Int,
    @SerializedName("xp_level")          val xpLevel: Int,
    @SerializedName("total_study_minutes") val totalStudyMinutes: Int,
//    @SerializedName("promoted_at")        val promotedAt: String?,
//    @SerializedName("next_tier_progress") val nextTierProgress: Double,
    @SerializedName("is_studying_now")    val isStudyingNow: Boolean = false,
    // Active tab: when their current session in THIS room started — used
    // to drive a live-ticking timer client-side, same pattern as your own
    // session timer, rather than a number that's stale on arrival.
    @SerializedName("current_session_started_at") val currentSessionStartedAt: String? = null,
    // Inactive tab: last time this user was active specifically in this
    // room (not the global last_active_at, which spans all rooms).
    @SerializedName("last_active_at")     val lastActiveAt: String? = null,
    // Inactive tab: all-time contribution to this specific room.
    @SerializedName("room_total_minutes") val roomTotalMinutes: Int = 0,
    // Full leaderboard fields — today/week/month shown simultaneously per
    // row rather than gating behind a period selector.
    @SerializedName("today_minutes")      val todayMinutes: Int = 0,
    @SerializedName("week_minutes")       val weekMinutes: Int = 0,
    @SerializedName("month_minutes")      val monthMinutes: Int = 0,
    @SerializedName("rank_position")      val rankPosition: Int = 0,
    // "studying" | "online" | "offline" — see backend
    // TierRoomsService.ONLINE_WINDOW_MINUTES for what "online" means.
    val status: String = "offline",
    @SerializedName("badge_count")        val badgeCount: Int = 0
)

data class TierMembersResponseData(
    val members: List<TierMemberDto> = emptyList()
)

// ── Room Statistics (spec section 4: Room Insights) ────────────

data class RoomStatsTopPerformerDto(
    @SerializedName("user_id")   val userId: String = "",
    @SerializedName("user_name") val userName: String = "",
    val minutes: Int = 0
)

data class RoomStatsResponseData(
    @SerializedName("total_members")    val totalMembers: Int = 0,
    @SerializedName("active_members")   val activeMembers: Int = 0,
    @SerializedName("online_members")   val onlineMembers: Int = 0,
    @SerializedName("studying_now")     val studyingNow: Int = 0,
    @SerializedName("minutes_today")    val minutesToday: Int = 0,
    @SerializedName("minutes_this_week") val minutesThisWeek: Int = 0,
    @SerializedName("minutes_this_month") val minutesThisMonth: Int = 0,
    @SerializedName("highest_streak")   val highestStreak: Int = 0,
    @SerializedName("topPerformer")     val topPerformer: RoomStatsTopPerformerDto? = null
)

// ── Room Champions (redesign section 5) ─────────────────────────

data class RoomChampionDto(
    @SerializedName("user_id")    val userId: String = "",
    @SerializedName("user_name")  val userName: String = "",
    @SerializedName("avatar_url") val avatarUrl: String? = null,
    val minutes: Int = 0,
    // Only populated for mostImproved
    @SerializedName("delta_minutes") val deltaMinutes: Int? = null
)

data class RoomChampionsResponseData(
    val todayChampion: RoomChampionDto? = null,
    val weeklyChampion: RoomChampionDto? = null,
    val monthlyChampion: RoomChampionDto? = null,
    val mostImproved: RoomChampionDto? = null
)

// ── Personal Ranking (redesign section 4) ───────────────────────

data class MyRankResponseData(
    @SerializedName("rankPosition")       val rankPosition: Int? = null,
    @SerializedName("todayMinutes")       val todayMinutes: Int = 0,
    @SerializedName("weekMinutes")        val weekMinutes: Int = 0,
    @SerializedName("monthMinutes")       val monthMinutes: Int = 0,
    val streak: Int = 0,
    @SerializedName("minutesToNextRank")  val minutesToNextRank: Int? = null,
    @SerializedName("nextRankPosition")   val nextRankPosition: Int? = null
)

// ── Room Activity Feed (spec section 9) ─────────────────────────

data class ActivityFeedEntryDto(
    val id: String,
    @SerializedName("userId")   val userId: String? = null,
    @SerializedName("userName") val userName: String = "",
    @SerializedName("eventType") val eventType: String = "",  // joined|streak_milestone|promoted|demoted
    val metadata: Map<String, Any?> = emptyMap(),
    @SerializedName("createdAt") val createdAt: String = ""
)

data class ActivityFeedResponseData(
    val feed: List<ActivityFeedEntryDto> = emptyList()
)

// ── Study Session DTOs ────────────────────────────────────────

/**
 * Request body for POST /rooms/sessions/start
 */
data class StartSessionRequest(
    @SerializedName("roomId") val roomId: String? = null,
    val mode: String = "study",   // "study" | "pomodoro" | "silent"
    // The tier ROOM the user tapped to start this session (may differ
    // from their reward tier if they joined a lower unlocked room).
    // Backend uses this for presence/active counts and session display.
    val tierKey: String? = null
)

/**
 * Response from POST /rooms/sessions/start
 */
data class StartSessionResponseData(
    val sessionId: String,
    val startedAt: String,
    val mode: String,
    val tierId: String?,
    @SerializedName("heartbeatIntervalSeconds") val heartbeatIntervalSeconds: Int = 300
)

/**
 * Request body for POST /rooms/sessions/heartbeat
 */
data class HeartbeatRequest(
    val sessionId: String
)

/**
 * Response from POST /rooms/sessions/heartbeat
 * The ViewModel reads coinsEarnedThisBeat to update the live coin counter.
 */
data class HeartbeatResponseData(
    val isAfk: Boolean,
    @SerializedName("activeMinsThisBeat")    val activeMinsThisBeat: Int,
    @SerializedName("coinsEarnedThisBeat")   val coinsEarnedThisBeat: Int,
    @SerializedName("xpEarnedThisBeat")      val xpEarnedThisBeat: Int,
    @SerializedName("totalCoinsThisSession") val totalCoinsThisSession: Int,
    @SerializedName("totalXpThisSession")    val totalXpThisSession: Int,
    @SerializedName("totalActiveMinutes")    val totalActiveMinutes: Int,
    val message: String
)

/**
 * Request body for POST /rooms/sessions/end
 */
data class EndSessionRequest(
    val sessionId: String
)

/**
 * Response from POST /rooms/sessions/end — shown in the session summary sheet
 */
data class EndSessionResponseData(
    val sessionId: String,
    @SerializedName("durationMinutes")    val durationMinutes: Int,
    @SerializedName("activeMinutes")      val activeMinutes: Int,
    @SerializedName("todayStudyMinutes")  val todayStudyMinutes: Int = 0,
    @SerializedName("totalCoins")         val totalCoins: Int,
    @SerializedName("totalXp")            val totalXp: Int,
    @SerializedName("bonusCoins")         val bonusCoins: Int,
    val message: String
)

/**
 * Active session data returned by GET /rooms/sessions/active
 * Null session means no active session exists.
 */
data class ActiveSessionTierDto(
    @SerializedName("tierKey") val tierKey: String? = null,
    val name: String,
    @SerializedName("iconEmoji") val iconEmoji: String,
    @SerializedName("colorHex")  val colorHex: String
)

data class ActiveSessionDto(
    val id: String,
    val startedAt: String,
    val mode: String,
    @SerializedName("activeMinutes")  val activeMinutes: Int,
    @SerializedName("coinsEarned")    val coinsEarned: Int,
    @SerializedName("xpEarned")       val xpEarned: Int,
    @SerializedName("afkCount")       val afkCount: Int,
    @SerializedName("isAfkNow")       val isAfkNow: Boolean,
    @SerializedName("lastHeartbeat")  val lastHeartbeat: String,
    val tier: ActiveSessionTierDto?
)

data class ActiveSessionResponseData(
    val session: ActiveSessionDto?   // null = no active session
)

// ════════════════════════════════════════════════════════════
// RETROFIT INTERFACE
// ════════════════════════════════════════════════════════════

data class AtRiskData(
    @SerializedName("isAtRisk")    val isAtRisk: Boolean = false,
    @SerializedName("progress")    val progress: Float   = 0f,
    @SerializedName("threshold")   val threshold: Float  = 50f,
    @SerializedName("tierKey")     val tierKey: String   = "",
    @SerializedName("tierName")    val tierName: String  = "",
    @SerializedName("tierEmoji")   val tierEmoji: String = "",
    @SerializedName("demotionGraceUntil") val demotionGraceUntil: String? = null
)

data class ClaimPromotionTier(
    @SerializedName("key")   val key: String?   = null,
    @SerializedName("name")  val name: String?  = null,
    @SerializedName("emoji") val emoji: String? = null,
)

data class ClaimPromotionData(
    @SerializedName("promotedTo") val promotedTo: ClaimPromotionTier? = null,
)

interface TierRoomsApiService {

    // ── Tier Rooms ───────────────────────────────────────────

    /**
     * GET /rooms/tiers
     * Returns all 4 tier rooms with member counts and active session counts.
     * Used in: RoomsHubScreen lobby
     */
    @GET("rooms/tiers")
    suspend fun getAllTiers(): ApiResponse<TiersListResponseData>

    /**
     * GET /rooms/tiers/my
     * Returns the user's current tier + progress toward next tier.
     * Used in: RoomsHubScreen hero card + TierRoomScreen header
     */
    @GET("rooms/tiers/my")
    suspend fun getMyTier(): ApiResponse<MyTierResponseData>

    /**
     * GET /rooms/tiers/{tierKey}/members?page=1&limit=20
     * Returns paginated list of users currently in this tier.
     * Used in: TierRoomScreen → "Members" tab
     */
    @GET("rooms/tiers/{tierKey}/members")
    suspend fun getTierMembers(
        @Path("tierKey") tierKey: String,
        @Query("page")   page: Int = 1,
        @Query("limit")  limit: Int = 20
    ): ApiResponse<TierMembersResponseData>

    /**
     * GET /rooms/tiers/{tierKey}/leaderboard?period=weekly
     * Returns cron-computed leaderboard for this tier.
     * period: "weekly" | "monthly" | "alltime"
     * Used in: TierRoomScreen → "Leaderboard" tab
     */
    @GET("rooms/tiers/{tierKey}/leaderboard")
    suspend fun getTierLeaderboard(
        @Path("tierKey")   tierKey: String,
        @Query("period")   period: String = "weekly"
    ): ApiResponse<LeaderboardResponseData>

    /**
     * GET /rooms/tiers/{tierKey}/stats
     * Returns the Room Insights card data: member counts, hours today/this
     * week, highest streak in the room, top performer this week.
     */
    @GET("rooms/tiers/{tierKey}/stats")
    suspend fun getRoomStats(
        @Path("tierKey") tierKey: String
    ): ApiResponse<RoomStatsResponseData>

    /**
     * GET /rooms/tiers/{tierKey}/champions
     * Today/Weekly/Monthly champions + Most Improved member.
     */
    @GET("rooms/tiers/{tierKey}/champions")
    suspend fun getRoomChampions(
        @Path("tierKey") tierKey: String
    ): ApiResponse<RoomChampionsResponseData>

    /**
     * GET /rooms/tiers/{tierKey}/my-rank
     * Personal ranking + minutes needed to overtake the next rank up.
     */
    @GET("rooms/tiers/{tierKey}/my-rank")
    suspend fun getMyRank(
        @Path("tierKey") tierKey: String
    ): ApiResponse<MyRankResponseData>

    /**
     * GET /rooms/tiers/{tierKey}/activity?limit=50
     * Returns the room's recent activity feed (joins, streak milestones,
     * promotions, demotions), newest first. New entries also arrive live
     * over the socket as "room:activity" while connected.
     */
    @GET("rooms/tiers/{tierKey}/activity")
    suspend fun getActivityFeed(
        @Path("tierKey") tierKey: String,
        @Query("limit")  limit: Int = 50
    ): ApiResponse<ActivityFeedResponseData>

    // ── Study Sessions ───────────────────────────────────────

    /**
     * POST /rooms/sessions/start
     * Creates a new study session. Returns sessionId used in subsequent calls.
     * Error 409 if user already has an active session.
     * Used in: StudySessionViewModel.startSession()
     */
    @POST("rooms/sessions/start")
    suspend fun startSession(
        @Body body: StartSessionRequest
    ): ApiResponse<StartSessionResponseData>

    /**
     * POST /rooms/sessions/heartbeat
     * Must be called every 5 minutes to:
     *   - Prove user is active (AFK detection)
     *   - Receive coin + XP award for the verified interval
     * If gap since last heartbeat > 7 min: isAfk=true, no coins awarded.
     * Used in: StudySessionViewModel heartbeat coroutine loop
     */
    @POST("rooms/sessions/heartbeat")
    suspend fun heartbeat(
        @Body body: HeartbeatRequest
    ): ApiResponse<HeartbeatResponseData>

    /**
     * POST /rooms/sessions/end
     * Ends the active session. Awards bonus coins if >= 30 active minutes.
     * Returns session summary shown in the EndSessionSheet composable.
     * Used in: StudySessionViewModel.endSession()
     */
    @POST("rooms/sessions/end")
    suspend fun endSession(
        @Body body: EndSessionRequest
    ): ApiResponse<EndSessionResponseData>

    /**
     * GET /rooms/sessions/active
     * Returns the user's currently active session (or null).
     * Called on app resume to restore session state.
     * Used in: StudySessionViewModel.checkForExistingSession()
     */
    @GET("rooms/sessions/active")
    suspend fun getActiveSession(): ApiResponse<ActiveSessionResponseData>

    /**
     * GET /rooms/tiers/at-risk
     * Returns whether the user is at risk of demotion.
     * Called on RoomsHubScreen resume to show DemotionWarningBanner.
     */
    @GET("rooms/tiers/at-risk")
    suspend fun getAtRiskStatus(): ApiResponse<AtRiskData>

    /**
     * POST /rooms/tiers/claim-promotion
     * User calls this when all requirements met — immediate promotion, no midnight wait.
     */
    @POST("rooms/tiers/claim-promotion")
    suspend fun claimPromotion(): ApiResponse<ClaimPromotionData>
}