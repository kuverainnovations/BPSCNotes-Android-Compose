package com.example.bpscnotes.presentation.quiz

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.bpscnotes.core.language.LocalStrings
import com.example.bpscnotes.core.ui.AppErrorState
import com.example.bpscnotes.core.ui.AppEmptyState
import com.example.bpscnotes.core.ui.AppLoader
import com.example.bpscnotes.core.ui.t.BpscColors
import com.example.bpscnotes.presentation.navigation.popBackStackSafe

@Composable
fun TopicQuizScreen(
    navController: NavHostController,
    subject: String,
    topicTitle: String,
    viewModel: QuizViewModel = hiltViewModel()    // shared VM — Hilt provides same instance in same back-stack
) {
    val state by viewModel.uiState.collectAsState()
    val str = LocalStrings.current
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { com.example.bpscnotes.core.analytics.Event.screenView("topic_quiz") }

    // Kick off quiz load when screen appears
    LaunchedEffect(subject, topicTitle) {
        if (state.activeSession == null && !state.isLoadingDetail) {
            viewModel.startTopicQuiz(subject)
        }
    }

    when {
        // ── Result ─────────────────────────────────────────────
        state.result != null && state.activeSession != null -> {
            QuizSummaryScreen(
                session       = state.activeSession!!,
                result        = state.result!!,
                onExit        = { viewModel.exitSession(); navController.popBackStackSafe() },
                navController = navController
            )
        }

        // ── Active play ────────────────────────────────────────
        state.activeSession != null && !state.isLoadingDetail -> {
            QuizSessionScreen(
                session   = state.activeSession!!,
                viewModel = viewModel,
                onExit    = { viewModel.exitSession(); navController.popBackStackSafe() }
            )
        }

        // ── Loading ────────────────────────────────────────────
        state.isLoadingDetail || state.isLoadingList -> AppLoader(message = str.loading)

        // ── Error — covers both startError (no quiz found) and network errors ──
        state.startError != null || state.detailError != null || state.listError != null -> {
            val msg = state.startError ?: state.detailError ?: state.listError ?: str.error
            val isNoQuiz = msg.contains("No quiz") || msg.contains("No MCQ")
            val cleanMsg = msg.replace("HTTP 400", "This quiz has no questions yet.")
                .replace("HTTP 404", "Quiz not found.")
                .replace("HTTP 403", "Access denied.")
                .replace("HTTP 500", "Server error. Please try again later.")
            if (isNoQuiz) {
                // No quiz available — show friendly empty state, not an error
                AppEmptyState(emoji = "📚", title = cleanMsg,
                    actionLabel = str.back, onAction = { navController.popBackStackSafe() })
            } else {
                AppErrorState(
                    message = cleanMsg,
                    onRetry = { viewModel.clearErrors(); viewModel.startTopicQuiz(subject) },
                    secondaryAction = { OutlinedButton(onClick = { navController.popBackStackSafe() }, shape = RoundedCornerShape(12.dp)) { Text("← " + str.back) } }
                )
            }
        }

        // ── Intro screen (before quiz starts) ─────────────────
        else -> {
            TopicQuizIntroScreen(
                subject    = subject,
                topicTitle = topicTitle,
                maxCoins   = viewModel.coinsConfig.coins("topic_quiz", 15),
                navController = navController,
                onStart    = { viewModel.startTopicQuiz(subject) }
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// INTRO SCREEN
// ─────────────────────────────────────────────────────────────

@Composable
private fun TopicQuizIntroScreen(
    subject: String,
    topicTitle: String,
    maxCoins: Int = 15,
    navController: NavHostController,
    onStart: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val str = LocalStrings.current
    Box(modifier = Modifier.fillMaxSize().background(cs.background)) {
        Column(modifier = Modifier.fillMaxSize()) {

            Box(
                modifier = Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Color(0xFF0A2472), Color(0xFF1565C0), Color(0xFF1E88E5)), Offset(0f, 0f), Offset(400f, 300f)))
                    .statusBarsPadding().padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(0.15f)).clickable { navController.popBackStackSafe() }, contentAlignment = Alignment.Center) {
                        androidx.compose.material3.Icon(Icons.Rounded.ArrowBack, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(str.topicQuizTitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.7f))
                        Text(topicTitle, style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.ExtraBold, lineHeight = 28.sp)
                    }
                }
            }

            Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = cs.surface), elevation = CardDefaults.cardElevation(3.dp)) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(str.topicQuizDetails, style = MaterialTheme.typography.titleLarge, color = cs.onSurface, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            TopicStat("📝", "10", "Questions")
                            TopicStat("⏱️", "30s", str.topicQuizPerQuestion)
                            TopicStat("🪙", "+$maxCoins", "Max Coins")
                        }
                        HorizontalDivider(color = cs.outline)
                        listOf(
                            "✅  " + str.topicQuizCoin,
                            "⏭️  " + str.topicQuizSkip,
                            "💡  " + str.topicQuizHint,
                            "⏰  " + str.topicQuizTimer,
                            "📊  " + str.topicQuizReview
                        ).forEach { rule ->
                            Text(rule, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, lineHeight = 20.sp)
                        }
                    }
                }

                SubjectChip(subject)

                Spacer(Modifier.weight(1f))

                Button(
                    onClick  = onStart,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape    = RoundedCornerShape(14.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = BpscColors.Primary)
                ) {
                    Text(str.topicQuizStart, style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
}

@Composable
private fun TopicStat(icon: String, value: String, label: String) {
    val cs = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 22.sp)
        Text(value, style = MaterialTheme.typography.titleLarge, color = cs.onSurface, fontWeight = FontWeight.ExtraBold)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
    }
}