package com.example.bpscnotes.presentation.payment

import android.app.Activity
import android.content.Context
import android.util.Log
import com.example.bpscnotes.core.network.toUserMessage
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.bpscnotes.core.language.AppStrings
import com.example.bpscnotes.core.language.LocalStrings
import com.example.bpscnotes.core.ui.AppLoader
import com.example.bpscnotes.core.ui.t.BpscColors
import com.example.bpscnotes.data.remote.api.SubscriptionPlanDto
import com.example.bpscnotes.presentation.navigation.popBackStackSafe

import com.cashfree.pg.api.CFPaymentGatewayService
import com.cashfree.pg.core.api.CFSession
import com.cashfree.pg.core.api.CFTheme
import com.cashfree.pg.core.api.callback.CFCheckoutResponseCallback
import com.cashfree.pg.core.api.exception.CFException
import com.cashfree.pg.ui.api.CFDropCheckoutPayment

// ─────────────────────────────────────────────────────────────
// SUBSCRIPTION PAYMENT SCREEN
// ─────────────────────────────────────────────────────────────
@Composable
fun SubscriptionPaymentScreen(
    navController: NavHostController,
    viewModel: PaymentViewModel = hiltViewModel()
) {
    val str = LocalStrings.current
    val cs = MaterialTheme.colorScheme
    val state   by viewModel.state.collectAsState()
    val context = LocalContext.current

    // Launch Cashfree SDK when payment_session_id is ready.
    // Consume immediately so recompose doesn't re-trigger.
    LaunchedEffect(state.paymentSessionId, state.providerOrderId) {

        val sessionId   = state.paymentSessionId   ?: return@LaunchedEffect
        val orderId     = state.providerOrderId     ?: return@LaunchedEffect
        val environment = state.paymentEnvironment  // 'sandbox' | 'production' from backend

        viewModel.consumePaymentSessionId()

        launchCashfree(
            context = context,
            sessionId = sessionId,
            orderId = orderId,
            environment = environment,
            onSuccess = { cfPaymentId ->
                viewModel.confirmSubscription(cfPaymentId)
            },
            onFailure = { code, msg ->
                viewModel.handlePaymentFailure(code, msg)
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize().background(cs.background)) {
        when {
            state.isSuccess -> SuccessScreen(
                title   = str.paymentActivated,
                message = str.paymentWelcome,
                bonusCoins = state.bonusCoins,
                onDone  = { navController.popBackStackSafe() }
            )
            else -> Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Box(modifier = Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Color(0xFF0A2472), Color(0xFF1565C0))))
                    .statusBarsPadding().padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(modifier = Modifier.size(36.dp).clip(CircleShape)
                            .background(Color.White.copy(0.15f))
                            .clickable { navController.popBackStackSafe() },
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.ArrowBack, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(str.paymentGetPro, style = MaterialTheme.typography.headlineSmall,
                                color = Color.White, fontWeight = FontWeight.ExtraBold)
                            Text(str.paymentUnlockAll, style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(0.7f))
                        }
                        // Pro badge in header
                        Box(
                            modifier = Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
                                .background(Color(0xFFFFD700).copy(0.25f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            androidx.compose.material3.Text(
                                "⭐ PRO",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFFFFD700),
                                fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

                    // Error
                    state.error?.let { err ->
                        Card(shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE8E8))) {
                            Row(modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Warning, null, tint = Color(0xFFE74C3C), modifier = Modifier.size(18.dp))
                                Text(err, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF721C24), modifier = Modifier.weight(1f))
                                Icon(Icons.Rounded.Close, null, tint = Color(0xFFE74C3C),
                                    modifier = Modifier.size(16.dp).clickable { viewModel.clearError() })
                            }
                        }
                    }

                    // Features card
                    Card(shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cs.surface),
                        elevation = CardDefaults.cardElevation(2.dp)) {
                        Column(modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(str.paymentWhatsIncluded, style = MaterialTheme.typography.titleMedium,
                                color = cs.onSurface, fontWeight = FontWeight.Bold)
                            val features = listOf(
                                str.paymentBenefit1,
                                str.paymentBenefit2,
                                str.paymentBenefit3,
                                str.paymentBenefit4,
                                str.paymentBenefit5,
                                str.paymentBenefit6,
                                str.paymentBenefit7
                            )
                            features.forEach { f ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Check, null, tint = Color(0xFF2ECC71),
                                        modifier = Modifier.size(16.dp))
                                    Text(f, style = MaterialTheme.typography.bodyMedium,
                                        color = cs.onSurface)
                                }
                            }
                        }
                    }

                    // Plan selector
                    Text(str.paymentChoosePlan, style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurface, fontWeight = FontWeight.Bold)

                    if (state.isLoadingPlans) { AppLoader(modifier = Modifier.fillMaxWidth().height(120.dp)) } else {
                        state.plans.forEach { plan ->
                            PlanCard(
                                plan       = plan,
                                isSelected = plan.id == state.selectedPlan?.id,
                                onSelect   = { viewModel.selectPlan(plan) }
                            )
                        }
                    }

                    // Coupon code
                    CouponSection(
                        couponCode    = state.couponCode,
                        couponApplied = state.couponApplied,
                        couponError   = state.couponError,
                        onCodeChange  = { viewModel.setCouponCode(it) },
                        onApply       = { viewModel.applyCoupon() }
                    )

                    // Price breakdown
                    state.selectedPlan?.let { plan ->
                        PriceBreakdown(
                            baseAmount     = plan.price ?: 0.0,
                            couponDiscount = state.couponDiscount,
                            coinDiscount   = state.coinDiscount,
                            finalAmount    = state.finalAmount,
                            coinsAvailable = state.coinsAvailable,
                            coinsToUse     = state.coinsToUse,
                            coinToInrRate  = viewModel.coinsConfig.economy.coinToInrRate,
                            onCoinsToggle  = { viewModel.toggleCoinsDiscount() },
                            onCoinsSlide   = { viewModel.setCoinsToUse(it) }
                        )
                    }

                    // Payment note
                    Row(modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF0F4FF))
                        .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("🔒", fontSize = 16.sp)
                        Text(str.paymentSecure,
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant)
                    }
                }

                // Pay button
                Box(modifier = Modifier.fillMaxWidth().background(cs.surface)
                    .padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Button(
                        onClick  = { viewModel.createOrder() },
                        enabled  = state.selectedPlan != null && !state.isCreatingOrder && !state.isConfirming,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape    = RoundedCornerShape(14.dp),
                        colors   = ButtonDefaults.buttonColors(containerColor = BpscColors.Primary)
                    ) {
                        if (state.isCreatingOrder || state.isConfirming) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(if (state.isCreatingOrder) str.paymentCreating else str.paymentConfirming,
                                style = MaterialTheme.typography.titleMedium)
                        } else {
                            Text("Pay ${fmtRs(state.finalAmount)} →",
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}

/** Format a rupee amount: whole number when exact (₹10), two decimals when fractional (₹3.30) */
private fun fmtRs(amount: Double): String =
    if (amount == kotlin.math.floor(amount)) "₹${amount.toLong()}"
    else "₹${"%.2f".format(amount)}"

// ── Plan card ─────────────────────────────────────────────────
@Composable
private fun PlanCard(plan: SubscriptionPlanDto, isSelected: Boolean, onSelect: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val str = LocalStrings.current
    val savings = plan.savings ?: 0
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) BpscColors.PrimaryLight else Color.White),
        border = if (isSelected)
            androidx.compose.foundation.BorderStroke(2.dp, BpscColors.Primary)
        else null,
        elevation = CardDefaults.cardElevation(if (isSelected) 0.dp else 2.dp)) {
        Row(modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RadioButton(selected = isSelected, onClick = onSelect,
                colors = RadioButtonDefaults.colors(selectedColor = BpscColors.Primary))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(plan.name ?: "", style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurface, fontWeight = FontWeight.Bold)
                    if (savings > 0) {
                        Text("Save $savings%", style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF2ECC71), fontWeight = FontWeight.Bold, fontSize = 9.sp,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE8FDF4)).padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Text(plan.billingCycle ?: "", style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant)
                if ((plan.bonusCoins ?: 0) > 0) {
                    Text("🪙 +${plan.bonusCoins} bonus coins", style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFF57F17), fontWeight = FontWeight.Bold)
                }
            }
            // Price column — fixed width to prevent wrapping
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.widthIn(min = 80.dp)
            ) {
                if ((plan.originalPrice ?: 0.0) > (plan.price ?: 0.0)) {
                    Text("₹${plan.originalPrice}",
                        style = MaterialTheme.typography.bodySmall,
                        color = BpscColors.TextHint,
                        textDecoration = TextDecoration.LineThrough,
                        maxLines = 1)
                }
                Text(fmtRs(plan.price ?: 0.0),
                    style = MaterialTheme.typography.titleLarge,
                    color = if (isSelected) BpscColors.Primary else BpscColors.TextPrimary,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1)
                Text("/ ${plan.billingCycle?.replace("Billed ", "") ?: "month"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1)
            }
        }
    }
}

// ── Coupon section ────────────────────────────────────────────
@Composable
private fun CouponSection(
    couponCode: String, couponApplied: Boolean, couponError: String?,
    onCodeChange: (String) -> Unit, onApply: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val str = LocalStrings.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(str.paymentCoupon, style = MaterialTheme.typography.labelLarge,
            color = cs.onSurface, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = couponCode, onValueChange = onCodeChange,
                modifier = Modifier.weight(1f),
                singleLine = true, placeholder = { Text(str.paymentEnterCoupon) },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BpscColors.Primary,
                    unfocusedBorderColor = cs.outline,
                    disabledBorderColor = Color(0xFF2ECC71)
                ),
                enabled = !couponApplied,
                trailingIcon = if (couponApplied) ({
                    Icon(Icons.Rounded.Check, null, tint = Color(0xFF2ECC71))
                }) else null
            )
            Button(onClick = onApply, enabled = couponCode.isNotBlank() && !couponApplied,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (couponApplied) Color(0xFF2ECC71) else BpscColors.Primary)) {
                Text(if (couponApplied) str.paymentApplied else str.paymentApply)
            }
        }
        couponError?.let { err ->
            Text(err, style = MaterialTheme.typography.labelSmall, color = Color(0xFFE74C3C))
        }
        if (couponApplied) {
            Text(str.paymentSuccess, style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF2ECC71))
        }
    }
}

// ── Price breakdown ───────────────────────────────────────────
@Composable
private fun PriceBreakdown(
    baseAmount: Double, couponDiscount: Int, coinDiscount: Double, finalAmount: Double,
    coinsAvailable: Int, coinsToUse: Int, coinToInrRate: Double,
    onCoinsToggle: () -> Unit,
    onCoinsSlide: (Int) -> Unit = {}
) {
    val cs = MaterialTheme.colorScheme
    val str = LocalStrings.current
    val remainingPrice = (baseAmount - couponDiscount).coerceAtLeast(0.0)
    val maxByPrice     = if (coinToInrRate > 0) kotlin.math.ceil(remainingPrice / coinToInrRate).toInt() else 0
    val maxCoins       = minOf(coinsAvailable, maxByPrice).coerceAtLeast(0)

    Card(shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(2.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(str.paymentBreakdown, style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface, fontWeight = FontWeight.Bold)
            PriceRow(str.paymentBasePrice, fmtRs(baseAmount))
            if (couponDiscount > 0) PriceRow(str.paymentCouponDiscount, "−₹$couponDiscount", Color(0xFF2ECC71))
            if (coinDiscount > 0.0) PriceRow("Coin discount (${coinsToUse} 🪙)", "−${fmtRs(coinDiscount)}", Color(0xFFF57F17))
            HorizontalDivider(color = cs.outline)
            PriceRow(str.paymentTotal, fmtRs(finalAmount), BpscColors.Primary, bold = true)

            // ── Coin redemption slider ───────────────────────────────────
            if (maxCoins > 0) {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFFF8E1))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🪙", fontSize = 16.sp)
                            Text("Redeem coins", style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF5D4037), fontWeight = FontWeight.SemiBold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("$coinsToUse / $maxCoins", style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFFF57F17), fontWeight = FontWeight.Bold)
                            Text("🪙", fontSize = 12.sp)
                        }
                    }
                    Slider(
                        value         = coinsToUse.toFloat(),
                        onValueChange = { onCoinsSlide(it.toInt()) },
                        valueRange    = 0f..maxCoins.toFloat(),
                        steps         = if (maxCoins > 1) maxCoins - 1 else 0,
                        colors        = SliderDefaults.colors(
                            thumbColor       = Color(0xFFF57F17),
                            activeTrackColor = Color(0xFFF57F17)
                        )
                    )
                    val rateLabel = if (coinToInrRate == coinToInrRate.toInt().toDouble())
                        coinToInrRate.toInt().toString() else coinToInrRate.toString()
                    Text(
                        if (coinsToUse > 0) "Saves ${fmtRs(coinDiscount)}  ·  1 coin = ₹$rateLabel"
                        else "Slide to use your $coinsAvailable coins  ·  1 coin = ₹$rateLabel",
                        style = MaterialTheme.typography.labelSmall, color = Color(0xFF8D6E63)
                    )
                }
            }
        }
    }
}

@Composable
private fun PriceRow(label: String, value: String, color: Color = BpscColors.TextPrimary, bold: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val str = LocalStrings.current
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = color,
            fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.Normal)
    }
}

// ── Success screen ────────────────────────────────────────────
@Composable
fun SuccessScreen(title: String, message: String, bonusCoins: Int = 0, onDone: () -> Unit) {
    val str = LocalStrings.current
    Box(modifier = Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0A2472), Color(0xFF1565C0), BpscColors.Surface))),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp)) {
            Text("🎉", fontSize = 64.sp)
            Text(title, style = MaterialTheme.typography.headlineMedium,
                color = Color.White, fontWeight = FontWeight.ExtraBold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(message, style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(0.7f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            if (bonusCoins > 0) {
                Card(shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))) {
                    Row(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("🪙", fontSize = 24.sp)
                        Text("+$bonusCoins bonus coins added to your wallet!",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color(0xFF5D4037), fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BpscColors.Primary)) {
                Text(str.paymentStartLearning, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

// ── Cashfree launcher helper ──────────────────────────────────
/**
 * Launch Cashfree payment SDK.
 *
 * Build-time dependency required in app/build.gradle:
 *   implementation("com.cashfree.pg:api:2.+")
 *
 * [sessionId]  — payment_session_id returned by backend (POST /subscriptions/initiate
 *                or /courses/{id}/enroll or /study-materials/{id}/purchase/init)
 * [onSuccess]  — receives cfPaymentId; ViewModel then calls backend confirm endpoint
 *                which does server-side verification via GET /pg/orders/{orderId}/payments
 * [onFailure]  — receives (errorCode, errorMessage); code 0 = user cancelled
 */
fun launchCashfree(
    context: Context,
    sessionId: String,
    orderId: String,
    environment: String = "sandbox",  // 'sandbox' | 'production' — must match backend order
    onSuccess: (String) -> Unit,
    onFailure: (Int, String) -> Unit
){
    try {
        val activity = context as Activity

        // Register callbacks on the Activity before opening the SDK
        (activity as? com.example.bpscnotes.presentation.payment.CashfreePaymentListener)
            ?.setPaymentCallbacks(onSuccess, onFailure)

        // ── Cashfree SDK invocation ────────────────────────────────────────
        //
        //  val session = CFSession.CFSessionBuilder()
        //      .setEnvironment(CFSession.Environment.SANDBOX)   // or PRODUCTION
        //      .setPaymentSessionId(sessionId)
        //      .setOrderId("")   // optional; SDK derives it from session
        //      .build()
        //
        //  val theme = CFThemeBuilder()
        //      .setNavigationBarBackgroundColor("#1565C0")
        //      .setNavigationBarTextColor("#FFFFFF")
        //      .setPrimaryTextColor("#1565C0")
        //      .setBackgroundColor("#FFFFFF")
        //      .setPrimaryFont("montserrat_regular.ttf")
        //      .setSecondaryFont("montserrat_regular.ttf")
        //      .build()
        //
        //  val cfDropCheckoutPayment = CFDropCheckoutPayment.CFDropCheckoutPaymentBuilder()
        //      .setSession(session)
        //      .setCFUIPaymentModes(
        //          CFUPIIntentCheckoutPayment(),   // UPI intent (GPay, PhonePe, etc.)
        //          CFCardPayment(),                // Debit/Credit cards
        //          CFNetBankingPayment()           // Net banking
        //      )
        //      .setTheme(theme)
        //      .build()
        //
        //  CFPaymentGatewayService.getInstance()
        //      .doPayment(activity, cfDropCheckoutPayment)
        //
        // CFPaymentResultCallback must be implemented in MainActivity:
        //
        //  override fun onPaymentVerify(orderId: String) {
        //      // Cashfree has verified internally; now confirm server-side
        //      // The orderId here is Cashfree's order_id, NOT cfPaymentId.
        //      // Backend GET /pg/orders/{orderId}/payments returns cfPaymentId.
        //      // For simplicity, pass orderId to backend confirm and let it look up.
        //      (this as? MainActivity)?.onCashfreePaymentSuccess(orderId)
        //  }
        //  override fun onError(error: CFErrorResponse, orderId: String) {
        //      val code = if (error.status == "cancelled") 0 else -1
        //      (this as? MainActivity)?.onCashfreePaymentError(code, error.message ?: "Payment failed")
        //  }
        //
        // ── Until SDK is added to build.gradle, call onFailure to avoid crash ──
        //   onFailure(-99, "Cashfree SDK not yet linked. Add implementation(\"com.cashfree.pg:api:2.+\") to app/build.gradle.")

        // Resolve CFSession.Environment from the backend-provided string.
        // The payment_session_id is environment-scoped: a production session MUST
        // be opened with Environment.PRODUCTION and vice-versa, otherwise Cashfree
        // returns "authentication Failed" without opening the payment sheet.
        val cfEnvironment = if (environment == "production")
            CFSession.Environment.PRODUCTION
        else
            CFSession.Environment.SANDBOX

        Log.e("CF_DEBUG", "======================")
        Log.e("CF_DEBUG", "sessionId   = $sessionId")
        Log.e("CF_DEBUG", "orderId     = $orderId")
        Log.e("CF_DEBUG", "environment = $environment → $cfEnvironment")
        Log.e("CF_DEBUG", "activity    = ${activity::class.java.simpleName}")
        Log.e("CF_DEBUG", "======================")
        try {
            val session = CFSession.CFSessionBuilder()
                .setEnvironment(cfEnvironment)
                .setPaymentSessionID(sessionId)
                .setOrderId(orderId)
                .build()

            val theme = CFTheme.CFThemeBuilder()
                .setNavigationBarBackgroundColor("#1565C0")
                .setNavigationBarTextColor("#FFFFFF")
                .build()

            val checkout = CFDropCheckoutPayment.CFDropCheckoutPaymentBuilder()
                .setSession(session)
                //.setTheme(theme)
                .build()

            CFPaymentGatewayService.getInstance()
                .doPayment(activity, checkout)

        } catch (e: CFException) {
            onFailure(-1, e.message ?: "Cashfree launch failed")
        }

    } catch (e: Exception) {
        onFailure(-1, "Failed to open payment: ${e.localizedMessage ?: "Unknown error"}")
    }
}