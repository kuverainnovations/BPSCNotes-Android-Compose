package com.example.bpscnotes.presentation.quiz

import com.example.bpscnotes.core.network.toUserMessage

import com.example.bpscnotes.data.remote.api.AuthApiService
import com.example.bpscnotes.data.remote.api.QuizzesApiService

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.bpscnotes.core.analytics.Event
import com.example.bpscnotes.data.remote.api.*
import com.example.bpscnotes.data.remote.dto.UserDto
import dagger.hilt.android.lifecycle.HiltViewModel
import com.example.bpscnotes.core.events.RefreshEvent
import com.example.bpscnotes.core.events.RefreshEventBus
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.HttpException
import javax.inject.Inject

// ─────────────────────────────────────────────────────────────
// DOMAIN MODELS
// ─────────────────────────────────────────────────────────────

data class QuizSessionQuestion(
    val id: String,
    val question: String,
    val options: List<String>,
    val subject: String,
    val correctOptionLetter: String? = null,
    val explanation: String? = null,
    val questionType: String = "text",
    val questionImageUrl: String? = null,
    val optionType: String = "text",
    val optionImages: List<String?> = emptyList(),
) {
    val correctIndex: Int get() = when (correctOptionLetter?.lowercase()) {
        "a" -> 0; "b" -> 1; "c" -> 2; "d" -> 3; else -> -1
    }
    val isImageQuestion: Boolean get() = questionType == "image" && !questionImageUrl.isNullOrBlank()
    val isImageOptions:  Boolean get() = optionType == "image"
}

data class QuizSession(
    val id: String,
    val title: String,
    val subtitle: String,
    val durationMins: Int,
    val coinsReward: Int,
    val questions: List<QuizSessionQuestion>,
    // ── Negative marking — admin-configurable per quiz ────────
    val negativeMarkingEnabled: Boolean = false,
    val marksPerCorrect: Double = 1.0,
    val marksPerWrong: Double = 0.0,
) {
    val totalMarks: Double get() = questions.size * marksPerCorrect
}

data class QuizAnswerDetail(
    val question: QuizSessionQuestion,
    val selectedLetter: String,
    val correctLetter: String,
    val isCorrect: Boolean,
    val isSkipped: Boolean,
    val explanation: String,
    /** Marks this question contributed: +marksPerCorrect, -marksPerWrong, or 0 if skipped */
    val marks: Double = 0.0
) {
    val selectedIndex: Int get() = when (selectedLetter.lowercase()) { "a"->0;"b"->1;"c"->2;"d"->3; else->-1 }
    val correctIndex:  Int get() = when (correctLetter.lowercase())   { "a"->0;"b"->1;"c"->2;"d"->3; else->-1 }
}

data class QuizResult(
    val score: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val totalQuestions: Int,
    val accuracy: Double,
    val coinsEarned: Int,
    val timeTakenSecs: Int,
    val answerDetails: List<QuizAnswerDetail>,
    // ── Rank / percentile from backend ───────────────────────
    val rank: Int = 0,
    val percentile: Double = 0.0,
    // ── Negative marking breakdown ────────────────────────────
    val negativeMarkingEnabled: Boolean = false,
    val marksPerCorrect: Double = 1.0,
    val marksPerWrong: Double = 0.0,
    val totalMarks: Double = 0.0,
    val marksObtained: Double = 0.0,
    val negativeMarks: Double = 0.0,
    val finalScore: Double = 0.0,
)

// ─────────────────────────────────────────────────────────────
// UI STATE
// ─────────────────────────────────────────────────────────────

data class QuizUiState(
    // ── List / Lobby ──────────────────────────────────────────
    // allQuizzes: full unfiltered list — client-side search/filter derived from this
    val allQuizzes: List<QuizPreviewDto>      = emptyList(),
    val dailyQuizzes: List<QuizPreviewDto>    = emptyList(),
    val topicQuizzes: List<QuizPreviewDto>    = emptyList(),
    val mockTestQuizzes: List<QuizPreviewDto> = emptyList(),
    val userProfile: UserDto?                 = null,
    val isLoadingList: Boolean                = true,
    val listError: String?                    = null,
    // Search / filter state — applied client-side over allQuizzes
    val searchQuery: String                   = "",
    val selectedType: String                  = "all",  // "all" | "daily" | "topic" | "mock"

    // ── Detail / Intro (pre-start) ────────────────────────────
    // The preview DTO loaded for the detail screen (no questions yet)
    val quizDetail: QuizPreviewDto?           = null,
    val isLoadingDetail: Boolean              = false,
    val detailError: String?                  = null,

    // ── Active session ────────────────────────────────────────
    val activeSession: QuizSession?           = null,
    val isStartingQuiz: Boolean               = false,
    val startError: String?                   = null,

    // ── Play state (persisted in VM — survives recomposition) ─
    val selectedAnswers: Map<String, String>  = emptyMap(),
    val isSubmitting: Boolean                 = false,
    val submitError: String?                  = null,

    // ── Result ────────────────────────────────────────────────
    val result: QuizResult?                   = null,

    // ── Per-quiz leaderboard (loaded after submit) ────────────
    val leaderboard: List<com.example.bpscnotes.data.remote.api.QuizLeaderboardItemResponse> = emptyList(),
    val isLoadingLeaderboard: Boolean         = false,
)

// ─────────────────────────────────────────────────────────────
// VIEW MODEL
// ─────────────────────────────────────────────────────────────

@HiltViewModel
class QuizViewModel @Inject constructor(
    private val quizzesApi: QuizzesApiService,
    private val bus: RefreshEventBus,
    private val authApi: AuthApiService,
    private val cacheInvalidator: com.example.bpscnotes.core.network.CacheInvalidator,
    val coinsConfig: com.example.bpscnotes.core.config.CoinsConfigRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(QuizUiState())
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    private var listJob:   Job? = null
    private var detailJob: Job? = null
    private var startJob:  Job? = null

    init { loadLobby()
        // ── Refresh on bus events ─────────────────────────────
        viewModelScope.launch {
            bus.events.collect { event ->
                when (event) {
                    is RefreshEvent.QuizCompleted,
                    is RefreshEvent.CoinsChanged -> loadLobby()
                    else -> {}
                }
            }
        }
    }

    // ── 1. LIST ───────────────────────────────────────────────

    fun loadLobby() {
        listJob?.cancel()
        listJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoadingList = true, listError = null) }
            try {
                val quizzesResponse = quizzesApi.getQuizzes(limit = 50)
                val profileResponse = try { authApi.getMe() } catch (e: Exception) { null }
                val all = quizzesResponse.data?.quizzes ?: emptyList()

                _uiState.update { state ->
                    // Apply existing search/filter to newly loaded data
                    val filtered = applyQuizFilter(all, state.searchQuery, state.selectedType)
                    state.copy(
                        allQuizzes      = all,
                        dailyQuizzes    = filtered.filter { q -> q.type == "daily" },
                        topicQuizzes    = filtered.filter { q -> q.type == "topic" },
                        mockTestQuizzes = filtered.filter { q -> q.type == "mock" },
                        userProfile     = profileResponse?.data?.user,
                        isLoadingList   = false
                    )
                }
            } catch (e: Exception) {
                Log.e("QuizVM", "loadLobby: ${e.message}", e)
                _uiState.update {
                    it.copy(isLoadingList = false, listError = e.toUserMessage("Failed to load quizzes"))
                }
            }
        }
    }

    /** Set search query and recompute filtered lists client-side (no network call) */
    fun setSearchQuery(q: String) {
        _uiState.update { state ->
            val filtered = applyQuizFilter(state.allQuizzes, q, state.selectedType)
            state.copy(
                searchQuery     = q,
                dailyQuizzes    = filtered.filter { it.type == "daily" },
                topicQuizzes    = filtered.filter { it.type == "topic" },
                mockTestQuizzes = filtered.filter { it.type == "mock" },
            )
        }
    }

    /** Set type filter ("all", "daily", "topic", "mock") and recompute */
    fun setTypeFilter(type: String) {
        _uiState.update { state ->
            val filtered = applyQuizFilter(state.allQuizzes, state.searchQuery, type)
            state.copy(
                selectedType    = type,
                dailyQuizzes    = filtered.filter { it.type == "daily" },
                topicQuizzes    = filtered.filter { it.type == "topic" },
                mockTestQuizzes = filtered.filter { it.type == "mock" },
            )
        }
    }

    private fun applyQuizFilter(all: List<QuizPreviewDto>, query: String, type: String): List<QuizPreviewDto> {
        var list = all
        if (type != "all") list = list.filter { it.type == type }
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter { quiz ->
                quiz.title.lowercase().contains(q) ||
                        (quiz.subject?.lowercase()?.contains(q) == true) ||
                        (quiz.examTags?.any { it.lowercase().contains(q) } == true)
            }
        }
        return list
    }

    // ── 2. DETAIL (intro screen) ──────────────────────────────

    /**
     * Loads quiz metadata (no questions) for the detail/intro screen.
     * GET /quizzes/:id — returns quiz info only.
     */
    fun loadQuizDetail(quizId: String) {
        detailJob?.cancel()
        detailJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoadingDetail = true, detailError = null, quizDetail = null) }
            try {
                val response = quizzesApi.getQuizDetail(quizId)
                val detail   = response.data ?: throw Exception("Quiz not found")
                _uiState.update {
                    it.copy(quizDetail = detail.quiz, isLoadingDetail = false)
                }
            } catch (e: Exception) {
                Log.e("QuizVM", "loadQuizDetail: ${e.message}", e)
                _uiState.update {
                    it.copy(isLoadingDetail = false, detailError = e.toUserMessage("Failed to load quiz"))
                }
            }
        }
    }

    // ── 3. START (creates session with questions) ─────────────

    /**
     * Called from QuizDetail "Start Quiz" button.
     * Calls POST /quizzes/:id/start → returns questions for this attempt.
     * On success navigates to QuizPlay (caller handles navigation).
     */
    fun startQuiz(quizId: String) {
        startJob?.cancel()
        startJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isStartingQuiz  = true,
                    startError      = null,
                    activeSession   = null,
                    selectedAnswers = emptyMap(),
                    result          = null,
                    submitError     = null
                )
            }
            try {
                val response  = quizzesApi.startQuiz(quizId)
                val data      = response.data ?: throw Exception("Failed to start quiz")
                val quiz      = data.quiz
                val questions = data.questions.map { q ->
                    QuizSessionQuestion(
                        id               = q.id,
                        question         = q.questionText,
                        options          = q.optionTexts,
                        subject          = q.subject ?: quiz.subject,
                        explanation      = q.explanation,
                        questionType     = q.questionType,
                        questionImageUrl = q.questionImageUrl,
                        optionType       = q.optionType,
                        optionImages     = q.optionImages
                    )
                }
                if (questions.isEmpty()) throw Exception("This quiz has no questions yet. Ask admin to add questions.")

                val session = QuizSession(
                    id           = quiz.id,
                    title        = quiz.title,
                    subtitle     = "${questions.size} questions · ${quiz.durationMins} min · ${quiz.subject}",
                    durationMins = quiz.durationMins,
                    coinsReward  = quiz.coinsReward,
                    questions    = questions,
                    negativeMarkingEnabled = quiz.negativeMarkingEnabled,
                    marksPerCorrect        = quiz.marksPerCorrect,
                    marksPerWrong          = quiz.marksPerWrong,
                )
                _uiState.update { it.copy(activeSession = session, isStartingQuiz = false) }
            } catch (e: Exception) {
                Log.e("QuizVM", "startQuiz: ${e.message}", e)
                // Parse actual JSON error body — e.message only says "HTTP 400"
                val body = if (e is HttpException) e.response()?.errorBody()?.string() ?: "" else ""
                val msg = when {
                    body.contains("not yet available", ignoreCase = true) ||
                            body.contains("scheduled", ignoreCase = true) ->
                        "not_yet_available"
                    body.contains("no questions", ignoreCase = true) ||
                            e.message?.contains("400") == true ->
                        "This quiz has no questions yet. Please try another quiz or contact admin."
                    e.message?.contains("404") == true -> "Quiz not found."
                    e.message?.contains("403") == true -> "You don't have access to this quiz."
                    else -> e.toUserMessage("Failed to start quiz. Please try again.")
                }
                _uiState.update { it.copy(isStartingQuiz = false, startError = msg) }
            }
        }
    }

    // ── 4. RECORD ANSWER ─────────────────────────────────────

    fun recordAnswer(questionId: String, letter: String) {
        _uiState.update { it.copy(selectedAnswers = it.selectedAnswers + (questionId to letter)) }
    }

    fun getAnswer(questionId: String): String? = _uiState.value.selectedAnswers[questionId]

    // ── 5. SUBMIT ─────────────────────────────────────────────

    fun submitQuiz(timeTakenSecs: Int) {
        val session = _uiState.value.activeSession ?: return
        // Guard against double-submit (timer + button can both trigger simultaneously)
        if (_uiState.value.isSubmitting || _uiState.value.result != null) return
        val answers = _uiState.value.selectedAnswers

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, submitError = null) }
            try {
                // Only send questions the user actually answered — skipped questions
                // must NOT default to "a", that would count as a wrong answer unfairly
                val requestAnswers = session.questions.mapNotNull { q ->
                    val answer = answers[q.id] ?: return@mapNotNull null
                    QuizAnswerRequest(questionId = q.id, answer = answer)
                }
                val response = quizzesApi.submitQuiz(
                    session.id,
                    QuizSubmitRequest(answers = requestAnswers, timeTakenSecs = timeTakenSecs)
                )
                val data = response.data ?: throw Exception("Empty submit response")

                val resultMap = data.answers.associateBy { it.questionId }
                val skippedIds = session.questions.filter { answers[it.id] == null }.map { it.id }.toSet()

                val updatedQuestions = session.questions.map { q ->
                    val r = resultMap[q.id]
                    q.copy(correctOptionLetter = r?.correctAnswer, explanation = r?.explanation)
                }

                val answerDetails = updatedQuestions.map { q ->
                    val r            = resultMap[q.id]
                    val isSkipped    = q.id in skippedIds
                    val selectedLtr  = answers[q.id] ?: ""

                    // For submitted questions: use backend's correctAnswer + isCorrect verdict
                    // For skipped questions: correctAnswer comes from q.correctOptionLetter
                    // which was set by updatedQuestions above (backend reveals it for all questions
                    // via the correctAnswer field in evaluated results)
                    // If backend didn't return it (skipped), fall back to the question's own field
                    val correctLtr   = when {
                        r != null        -> r.correctAnswer.lowercase()
                        !q.correctOptionLetter.isNullOrBlank() -> q.correctOptionLetter.lowercase()
                        else             -> ""
                    }
                    // isCorrect: trust backend for submitted, derive locally for skipped
                    val correct      = when {
                        r != null    -> r.isCorrect
                        isSkipped    -> false   // skipped = not correct
                        else         -> selectedLtr.isNotBlank() && selectedLtr == correctLtr
                    }

                    QuizAnswerDetail(
                        question       = q,
                        selectedLetter = selectedLtr,
                        correctLetter  = correctLtr,
                        isCorrect      = correct,
                        isSkipped      = isSkipped,
                        explanation    = r?.explanation ?: q.explanation ?: "",
                        marks          = r?.marks ?: 0.0
                    )
                }

                _uiState.update { state ->
                    state.copy(
                        activeSession   = session.copy(questions = updatedQuestions),
                        result          = QuizResult(
                            score          = data.score,
                            correctCount   = data.correct,
                            wrongCount     = data.wrong,
                            skippedCount   = skippedIds.size,
                            totalQuestions = data.total,
                            accuracy       = data.accuracy,
                            coinsEarned    = data.coinsEarned,
                            timeTakenSecs  = data.timeTakenSecs,
                            answerDetails  = answerDetails,
                            rank           = data.rank,
                            percentile     = data.percentile,
                            negativeMarkingEnabled = data.negativeMarkingEnabled,
                            marksPerCorrect        = data.marksPerCorrect,
                            marksPerWrong          = data.marksPerWrong,
                            totalMarks              = data.totalMarks,
                            marksObtained           = data.marksObtained,
                            negativeMarks           = data.negativeMarks,
                            finalScore              = data.finalScore,
                        ),
                        isSubmitting    = false,
                        // Update isAttempted AND myLastScore locally for immediate UI update
                        dailyQuizzes    = state.dailyQuizzes.map { q ->
                            if (q.id == session.id) q.copy(isAttempted = true, myLastScore = data.score) else q
                        },
                        topicQuizzes    = state.topicQuizzes.map { q ->
                            if (q.id == session.id) q.copy(isAttempted = true, myLastScore = data.score) else q
                        },
                        mockTestQuizzes = state.mockTestQuizzes.map { q ->
                            if (q.id == session.id) q.copy(isAttempted = true, myLastScore = data.score) else q
                        }
                    )
                }
                // Evict cached /auth/me and /coins so header coin count
                // refreshes immediately when loadLobby() re-fetches the profile
                cacheInvalidator.evict(com.example.bpscnotes.core.network.CacheInvalidator.QUIZ_ENDPOINTS)

                // Broadcast so QuizListScreen's VM (separate hiltViewModel instance)
                // picks up the event and reloads the list with fresh scores + solved count
                bus.emit(RefreshEvent.QuizCompleted)

                // Auto-load per-quiz leaderboard so result screen shows it instantly
                loadLeaderboard(session.id)
            } catch (e: Exception) {
                Log.e("QuizVM", "submitQuiz: ${e.message}", e)
                _uiState.update { it.copy(isSubmitting = false, submitError = e.toUserMessage("Submit failed")) }
            }
        }
    }

    /** Fetch top-10 leaderboard for a quiz (called after submit) */
    fun loadLeaderboard(quizId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingLeaderboard = true) }
            try {
                val res = quizzesApi.getLeaderboard(quizId)
                _uiState.update { it.copy(
                    leaderboard = res.data?.leaderboard ?: emptyList(),
                    isLoadingLeaderboard = false
                )}
            } catch (e: Exception) {
                Log.w("QuizVM", "loadLeaderboard: ${e.message}")
                _uiState.update { it.copy(isLoadingLeaderboard = false) }
            }
        }
    }

    // ── 6. TOPIC QUIZ ─────────────────────────────────────────

    fun startTopicQuiz(subject: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingDetail = true, startError = null) }
            try {
                // Strategy 1: exact subject + topic type
                var quizzes = quizzesApi.getQuizzes(subject = subject, type = "topic", limit = 5)
                    .data?.quizzes ?: emptyList()

                // Strategy 2: exact subject, any type
                if (quizzes.isEmpty()) {
                    quizzes = quizzesApi.getQuizzes(subject = subject, limit = 5)
                        .data?.quizzes ?: emptyList()
                }

                // Strategy 3: broader subject match — filter out quizzes with 0 questions
                if (quizzes.isEmpty()) {
                    val all = quizzesApi.getQuizzes(limit = 50).data?.quizzes ?: emptyList()
                    quizzes = all.filter { q ->
                        q.totalQuestions > 0 && (
                                q.subject.contains(subject, ignoreCase = true) ||
                                        subject.contains(q.subject, ignoreCase = true)
                                )
                    }
                }

                // Strategy 4: absolute fallback — any topic quiz with questions
                if (quizzes.isEmpty()) {
                    quizzes = quizzesApi.getQuizzes(type = "topic", limit = 20)
                        .data?.quizzes?.filter { it.totalQuestions > 0 } ?: emptyList()
                }

                // Always skip quizzes with 0 questions — they will 400 on start
                val pick = quizzes.filter { it.totalQuestions > 0 }.firstOrNull()
                if (pick != null) {
                    // FIX: Reset isLoadingDetail before handing off to startQuiz
                    // startQuiz uses isStartingQuiz for its own spinner — it never resets
                    // isLoadingDetail, so the spinner from startTopicQuiz would stick forever
                    _uiState.update { it.copy(isLoadingDetail = false) }
                    startQuiz(pick.id)
                } else {
                    _uiState.update {
                        it.copy(
                            isLoadingDetail = false,
                            startError = "No MCQ quiz available right now. The admin needs to add quizzes for this topic."
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e("QuizVM", "startTopicQuiz: \${e.message}", e)
                val errorMsg = "Failed to load quiz. Please check your connection."
                _uiState.update {
                    it.copy(
                        isLoadingDetail = false,
                        startError = errorMsg
                    )
                }
            }
        }
    }

    // ── 7. RESET ──────────────────────────────────────────────

    fun exitSession() {
        _uiState.update {
            it.copy(
                activeSession   = null,
                selectedAnswers = emptyMap(),
                result          = null,
                isStartingQuiz  = false,
                isSubmitting    = false,
                submitError     = null,
                startError      = null
            )
        }
    }

    fun clearErrors() {
        _uiState.update {
            it.copy(listError = null, detailError = null, startError = null, submitError = null)
        }
    }
}